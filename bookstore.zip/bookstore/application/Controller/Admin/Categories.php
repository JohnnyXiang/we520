<?php
class Controller_Admin_Categories extends Controller_Admin_Abstract {
	function indexAction() {
		$categories = $this->getDbTableModel ( 'category' )->fetchAll ();
		$this->view->categories = $categories;
	}
	function addAction() {
		if (! empty ( $_POST ['category_name'] )) {
			$category = $this->getModel ( 'category' )->load ();
			$image = '';
			if ($_FILES ['image'] ['name']) {
				$image = $this->_uploadCategoryImage ( $_FILES ['image'] );
			}
			
			try{
				$category->setData('category_name',$_POST ['category_name'])
				->setData('category_description',$_POST ['category_description'])
				->setData('position',$_POST ['position']?$_POST ['position']:0)
				->setData('category_image',$image)
				->setData('status',$_POST ['status'])
				->save();
			
				$this->flashMessage('Category has been created successfully.');
				
				$this->redirect(BASEURL.'/admin.php?controller=categories');
			}catch(Exception $e){
				$this->flashMessage($e->getMessage());
			}
		}
	}
	private function _uploadCategoryImage($file) {
		$handle = new upload ( $file );
		if ($handle->uploaded) {		
			$handle->process ( MEDIA_DIR.'/catalog/category' );
			if ($handle->processed) {			
				$handle->clean ();
				return $handle->file_dst_name;
			} else {
				return '';
			}
		}
	}
}