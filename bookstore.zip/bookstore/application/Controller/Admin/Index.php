<?php
class Controller_Admin_Index extends Controller_Admin_Abstract {	

	
	
	
	function indexAction() {
		
		
	}
	
	
}