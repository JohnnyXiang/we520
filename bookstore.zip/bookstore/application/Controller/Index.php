<?php
class Controller_Index extends Controller_Abstract {



	function indexAction() {
		
	}
	


}