<?php
class Model_Category extends Model_Abstract{
	protected $_tbModel = 'Model_DbTable_Category';
}