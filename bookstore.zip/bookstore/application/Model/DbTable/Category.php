<?php
Class Model_DbTable_Category extends Model_DbTable_Abstract{
	protected $_rowClass = 'Model_Category';
	protected $_name = 'categories';
}